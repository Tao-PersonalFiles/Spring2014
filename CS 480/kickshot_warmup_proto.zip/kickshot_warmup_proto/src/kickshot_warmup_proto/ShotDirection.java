package kickshot_warmup_proto;

/**
 * @author Rob Kleffner
 */
public enum ShotDirection {
    LEFT,
    RIGHT
}
