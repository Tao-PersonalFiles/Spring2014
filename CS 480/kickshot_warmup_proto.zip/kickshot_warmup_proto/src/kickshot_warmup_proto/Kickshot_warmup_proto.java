package kickshot_warmup_proto;

/**
 * @author Rob Kleffner
 */
public class Kickshot_warmup_proto {
    public static void main(String[] args) {
        System.out.println("Welcome to KickShot!");
        
        Game g = new Game();
        g.PlayGame();
    }
}
