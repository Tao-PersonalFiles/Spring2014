package com.redcarddev.kickshot_real;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Jordan on 4/30/14.
 */
public class credits extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.credits);

    }
}
